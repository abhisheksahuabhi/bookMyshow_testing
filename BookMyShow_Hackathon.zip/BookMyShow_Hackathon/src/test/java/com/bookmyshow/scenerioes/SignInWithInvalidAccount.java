package com.bookmyshow.scenerioes;

import java.util.Set;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.bookmyshow.pages.MainPage;

import ReadExcelFile.ReadExcelSheet;


public class SignInWithInvalidAccount extends MainPage {
	
	
  @Test(priority=0)
  public void selectCity()  {
		  
	  String data[];
	  
	  ExtentTest test1 = report.createTest("selectCity");
	  
		 // call 'xlFilePath' from the MainPage.java
		  for(int i=0;i<1;i++) {
			  data=ReadExcelSheet.readExcelData(xlFilePath,i);
				  setCity(data[i]);
			  }
	  test1.pass("Current city get selected properly");
	
  }
	  
	  
	 
  @Test(priority=1)
  public void clickSignIn() {
	  ExtentTest test2 = report.createTest("clickSignIn");
	  
	  driver.findElement(alertNotifyLoc).click();
	  WebDriverWait wait = new WebDriverWait(driver,40);
	  wait.until(ExpectedConditions.elementToBeClickable(signInLoc));
	  driver.findElement(signInLoc).click();
	 //valid the Google page
	  Boolean actResult=driver.findElement(signInTitleLoc).isDisplayed();
	  Assert.assertTrue(actResult);
	
	  test2.pass("select signin button and pop up box displayed properly");
  }
  
  
  @Test(priority=2)
  public void continueWithGoogle() {
	  ExtentTest test3 = report.createTest("continueWithGoogle");
	  
	  try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		
		e.printStackTrace();
	}
	  mainPageWindow=driver.getWindowHandle();
	  
	  driver.findElement(continueGoogleLoc).click();
	  
	  test3.pass("properly clicked the continue with google button");
  }
  
  
  @Test(priority=3)
  public void ValidateGoogleSignInPage() {
	  ExtentTest test4 = report.createTest("ValidateGoogleSignInPage");
	  
	  Set<String> windowIds=driver.getWindowHandles();
	  String nextPageWindowID = null;
	  for(String window:windowIds) { 
		  if(!window.matches(mainPageWindow)) {
			  nextPageWindowID=window;
		  }
	  }
	  
	  driver.switchTo().window(nextPageWindowID);
	  Assert.assertEquals( driver.getTitle(), "Sign in � Google accounts");
	  
	  test4.pass("Validate the google sign in page properly");
  }
  
  
  @Test(priority=4)
  public void setInvalidEmail() {
	  ExtentTest test5 = report.createTest("setInvalidEmail");
	  
	  
	  setEmailField("abhi@gmial.cm");
	  clickNextBtn();
	  
	  try {
		Thread.sleep(3000);  
		takeScreenShot(driver,System.getProperty("user.dir")+"\\ScreensShots\\"+fileName);
	} catch (Exception e) {
		e.printStackTrace();
	}
	  
	  test5.pass("Properly set the field values in the form and takes screenshots");
  }
  
  

  @BeforeClass
	public void beforeClass() {
		setDriver();
		navigateURL();
		
		ExtentHtmlReporter Reporter2 = new ExtentHtmlReporter(System.getProperty("user.dir")+"\\test-output\\SignInWithInvalidAcc_extentReport.html");
		report = new ExtentReports();
		report.attachReporter(Reporter2);
		
		


	}

	@AfterClass
	public void afterClass() {
		closeBrowser();
		
		report.flush();
	}

}
