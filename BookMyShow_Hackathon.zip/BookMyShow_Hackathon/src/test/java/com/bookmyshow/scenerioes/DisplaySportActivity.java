package com.bookmyshow.scenerioes;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.bookmyshow.pages.SportsListPage;

import ReadExcelFile.ReadExcelSheet;

import org.testng.annotations.BeforeClass;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class DisplaySportActivity extends SportsListPage{
	
	
	
	
  @Test(priority=0)
  public void selectCity()  {
	  
	  String data[];
	  ExtentTest test1 = report.createTest("selectCity");
	 // call 'xlFilePath' from the MainPage.java
	  for(int i=0;i<1;i++) {
		  data=ReadExcelSheet.readExcelData(xlFilePath,i);
			  setCity(data[i]);
		  }
	 // setCity("Lucknow");
	  test1.pass("City get selected properly");
	   }
  
  
	@Test(priority=1)
	public void sportActivities() throws InterruptedException {
		
		ExtentTest test2 = report.createTest("sportActivities");
		
		driver.findElement(alertNotifyLoc).click();
		driver.findElement(sportsLoc).click();
		
		Thread.sleep(3000);
		Assert.assertEquals(driver.getTitle(), "Top Upcoming Sports Events in Lucknow | Live Sports Tournaments in Lucknow - BookMyShow");
		
		test2.pass("sports link selected properly");
	}
	
	
	@Test(priority=2)
	public void filterActivity() {
		
		ExtentTest test3 = report.createTest("filterActivity");
		
		driver.findElement(weekEndLoc).click();
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,300)", "");
	
		test3.pass("filters selected properly");
		
		}
	
	@Test(priority=3)
	public void displayActivityNameAndPrice() {
		
		ExtentTest test4 = report.createTest("displayActivityNameAndPrice");
		
		System.out.println(validateSportsList());
		
		test4.pass("Activity name and price displyed properly");
	}
	
	
	
	@BeforeClass
	public void beforeClass() {
		setDriver();
		navigateURL();
		
		ExtentHtmlReporter Reporter2 = new ExtentHtmlReporter(System.getProperty("user.dir")+"\\test-output\\DisplaySportsActivity_extentReport.html");
		report = new ExtentReports();
		report.attachReporter(Reporter2);
		
		


	}

	@AfterClass
	public void afterClass() {
		closeBrowser();
		
		report.flush();
	}


}
