package com.bookmyshow.scenerioes;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.bookmyshow.pages.MainPage;

import ReadExcelFile.ReadExcelSheet;

import org.testng.annotations.BeforeClass;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class DisplayMovieLanguage extends MainPage {
	


	@Test(priority=0)
	public void selectCity()  {
		String data[];
		ExtentTest test1 = report.createTest("selectCity");
		
		// call 'xlFilePath' from the MainPage.java
		for(int i=0;i<1;i++) {
			data=ReadExcelSheet.readExcelData(xlFilePath,i);
			setCity(data[i]);
		}
		test1.pass("Current City selected");
		// setCity("Lucknow");
	}


	@Test(priority=1)
	public void selectMovies() throws Exception {
		ExtentTest test2 = report.createTest("selectMovies");
		
		driver.findElement(alertNotifyLoc).click();
		driver.findElement(selectMovieLoc).click();


		Thread.sleep(3000);
		Assert.assertEquals(driver.getTitle(),"Lucknow Movie Tickets Online Booking & Showtimes near you - BookMyShow");
		test2.pass("movie button clicked");
	}
	@Test(priority=2)
	public void getAllLanguages() {

		ExtentTest test3 = report.createTest("getAllLanguages");

		languages=driver.findElements(languagesLoc);

		/* for(WebElement language:languages) {

		  System.out.println(language.getText());
	  }*/
		System.out.println("Movies are available in Following languages\n");
		for(int i=0;i<languages.size();i++) {
			System.out.println(languages.get(i).getText());
		}

		test3.pass("All languages get displayed");
	}



	



	@BeforeClass
	public void beforeClass() {
		setDriver();
		navigateURL();
		
		ExtentHtmlReporter Reporter1 = new ExtentHtmlReporter(System.getProperty("user.dir")+"\\test-output\\MovieLanguage_extentReport.html");
		report = new ExtentReports();
		report.attachReporter(Reporter1);
		
		


	}

	@AfterClass
	public void afterClass() {
		closeBrowser();
		
		report.flush();
	}


}
