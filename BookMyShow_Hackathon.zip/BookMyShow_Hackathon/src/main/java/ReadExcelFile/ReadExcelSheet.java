package ReadExcelFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ReadExcelSheet {
public static String[] readExcelData(String fileName, int rowNo) {
		
		String[] data;
		File file;
		FileInputStream fis = null;
		XSSFWorkbook workBook=null;
		
		
		
		file = new File(fileName);
		try {
			fis = new FileInputStream(file);
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		try {
			workBook = new XSSFWorkbook(fis);
			
		}catch(IOException e) {
			System.out.println("Input output error");
		}
		XSSFSheet sheet = workBook.getSheet("Sheet1");// Acc.to your sheet
		
	//	int rowCount=sheet.getLastRowNum();
	//	System.out.println("Total No of Rows: " + rowCount);
		
		 int cellCount = sheet.getRow(rowNo).getLastCellNum();
		data = new String[cellCount];

		
        for(int i=0; i<cellCount; i++) {
        	 
        		data[i] = sheet.getRow(rowNo).getCell(i).getStringCellValue();
        	
			
		}
		return data;
	}
}
