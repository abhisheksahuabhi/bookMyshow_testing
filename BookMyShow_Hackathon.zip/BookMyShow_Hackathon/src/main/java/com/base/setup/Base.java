 package com.base.setup;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.Assert;

public class Base {
	public static WebDriver driver;
	public static Properties prop;
	
  public  void setDriver() {
	 
	  if(prop==null) {
		  prop=new Properties();
		  try {
			FileInputStream file= new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\com\\config\\config.properties");
			prop.load(file);
		  } catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }
	  
	  
	  if(prop.getProperty("browserName").matches("chrome"))
		{
		  System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\src\\main\\resources\\drivers\\chromedriver.exe");
			
			driver=new ChromeDriver();
		}
		
		//To Open Firefox Browser
		if(prop.getProperty("browserName").matches("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"\\src\\main\\resources\\drivers\\geckodriver.exe");
			
			driver=new FirefoxDriver();
		}
		
	//To maximize the Browser Window
			driver.manage().window().maximize();
			driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
  }
  
  public void navigateURL() {
	  driver.get(prop.getProperty("URL"));
	  
	 // Assert.assertEquals(driver.getTitle(),
			//	"Coursera in India | Online Courses & Certificates From Top Institutions");

  }
  
  
  public void takeScreenShot(WebDriver webdriver,String fileWithPath) throws IOException{
		//Convert web driver object to TakeScreenshot
		TakesScreenshot scrShot =((TakesScreenshot)webdriver);
		//Call getScreenshotAs method to create image file
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		//Move image file to new destination
		File DestFile=new File(fileWithPath);
		//Copy file at destination
		FileHandler.copy(SrcFile, DestFile);
		
		}
  

  public void closeBrowser() {
	 driver.quit();
  }

}
