package com.bookmyshow.pages;

import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.base.setup.Base;

public class MainPage extends Base{
	
	// for extent report
	public ExtentReports report;
	public String xlFilePath=System.getProperty("user.dir")+"\\src\\main\\resources\\CityName.xlsx";
	//Used in signIn with Invalid Account details
	
	public By signInLoc=By.xpath("//*[@id=\"super-container\"]/div[2]/header/div[1]/div/div/div/div[2]/div[2]/div[1]");
	public By continueGoogleLoc=By.xpath("//*[@id=\"modal-root\"]/div/div/div/div/div[2]/div/div[1]/div/div[1]/div");
	public By signInTitleLoc=By.xpath("//*[@id=\"modal-root\"]/div/div/div/div/div[1]/div[2]");
	public By alertNotifyLoc=By.xpath("//*[@id=\"wzrk-cancel\"]");
	public String mainPageWindow;
	public Date date = new Date();
	public String fileName=date.toString().replace(":", "_").replace(" ", "_") + ".png";
	
	//Used in display movie Languages
	public By selectMovieLoc= By.xpath("//*[@id=\"super-container\"]/div[2]/header/div[2]/div/div/div/div[1]/div/a[1]");
	public By languagesLoc=By.xpath("//*[@id=\"super-container\"]/div[2]/div[4]/div[1]/div[1]/div[2]/div[1]/div[2]/div/div[2]/div[1]/div[1]");
	public List<WebElement> languages;
	
	
	
	// used in mainPage class
	
	By enterCityLoc=By.xpath("//*[@id=\"modal-root\"]/div/div/div/div[1]/div/div/input");
	By selectCityLoc=By.xpath("//*[@id=\"modal-root\"]/div/div/div/div[1]/div[2]/div/ul/li/span/strong"); 
	By emailLoc=By.xpath("//*[@id=\"identifierId\"]");
	By nextBtnLoc=By.xpath("//*[@id=\"identifierNext\"]/div/button/span");
	
	
	public void setCity(String city) {
		    driver.findElement(enterCityLoc).sendKeys(city);
		    WebDriverWait wait = new WebDriverWait(driver,40);
			wait.until(ExpectedConditions.elementToBeClickable(selectCityLoc));
			driver.findElement(selectCityLoc).click();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Assert.assertEquals(driver.getTitle(), "Movie Tickets, Plays, Sports, Events & Cinemas near Lucknow - BookMyShow");
	  
	}
	
	public void setEmailField(String email) {
		driver.findElement(emailLoc).sendKeys(email);
		
	}
	
	public void clickNextBtn() {
		driver.findElement(nextBtnLoc).click();
	}
	
	
	
//end of main class
}
