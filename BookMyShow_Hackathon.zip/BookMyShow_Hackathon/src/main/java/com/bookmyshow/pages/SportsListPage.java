package com.bookmyshow.pages;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class SportsListPage extends MainPage{
	//Used in Display sports Activity
		public By sportsLoc=By.xpath("//*[@id=\"super-container\"]/div[2]/header/div[2]/div/div/div/div[1]/div/a[5]");
		public By weekEndLoc=By.xpath("//*[@id=\"super-container\"]/div[2]/div[4]/div[1]/div[1]/div[2]/div[1]/div[2]/div[3]/div[2]/div/div");
		public By priceLOc=By.xpath("//*[@id=\"super-container\"]/div[2]/div[4]/div[2]/div/div[1]/div/div[2]/a/div/div[3]/div[4]/div");
		public By eventNameLoc=By.xpath("//*[@id=\"super-container\"]/div[2]/div[4]/div[2]/div/div[1]/div/div[2]/a/div/div[3]/div[1]/div");
		public By priceRangeLoc=By.xpath("//*[@id=\"super-container\"]/div[2]/div[4]/div[1]/div[1]/div[2]/div[4]/div[1]/div[1]/div/svg");
		public By resultLocator=By.xpath("//*[@id=\"super-container\"]/div[2]/div[4]/div[2]/div[1]/h1");

	
	// for scenerio one 
		class Sports {    
			int price;    
			String name;        
			Sports(int price,String name){      
			   this.name=name;    
			   this.price=price;    
			}    
			public String getName() {  
			   return name;  
			}  
			 
			public void setName(String name) {  
			   this.name = name;  
			}
			public int getPrice() {  
			   return price;  
			}  
			public void setPrice(int price) {  
			   this.price = price;  
			}  
			}

		//using the comparator to compare the value
		public class CompareSportsDate implements Comparator<Sports>{

			public int compare(Sports m1, Sports m2) {
			if(m1.getPrice() == m2.getPrice())
			return 0;
			else if(m1.getPrice() > m2.getPrice())
			return 1;
			else
			return -1;
			}

			}
		
		// validating the sports
		public String validateSportsList() {
			List<WebElement> names=driver.findElements(eventNameLoc);
			List<WebElement> prices=driver.findElements(priceLOc);
			String[] arr = new String[names.size()];
			        for (int i = 0; i < names.size(); i++) {
			            arr[i] = names.get(i).getText();
			        }
			        Integer[] arr1 = new Integer[prices.size()];
			        for (int i = 0; i < prices.size(); i++) {
			            arr1[i] =Integer.parseInt((prices.get(i).getText()).replaceAll("[^0-9]", ""));
			        }
			        
			        
			ArrayList<Sports> sportsList = new ArrayList<Sports>();
			for (int i=0;i<names.size();i++) {
			sportsList.add(new Sports(arr1[i],arr[i]));
			}
			
			
			CompareSportsDate compareSportsDate = new CompareSportsDate();
			Collections.sort(sportsList, compareSportsDate);

			System.out.println("\nSorting By Price");
			for (Sports sport : sportsList) {
			System.out.println("Price:"+sport.getPrice() +"     Sports:"+sport.getName() );
			}
			        String sportsResult =driver.findElement(resultLocator).getText();
			        return sportsResult;
			}
		
}
